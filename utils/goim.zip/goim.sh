#!/sbin/busybox sh
sed -i "/ro.goo./d" /system/build.prop
echo "ro.goo.developerid=M66B" >>/system/build.prop
echo "ro.goo.rom=Xtended" >>/system/build.prop
echo "ro.goo.version=0" >>/system/build.prop
